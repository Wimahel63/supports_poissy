<?php  
//creation d'un site complet : CRUD :create, read , update, delete, ou creer, lire, modifier, supprimer









?>